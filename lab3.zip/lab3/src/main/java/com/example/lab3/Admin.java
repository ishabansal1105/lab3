package com.example.lab3;

import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;

    public class Admin {
        public Label welcomeText;
        private int ID;
        private String Name;
        private String Email;
        private int Password;

        public Admin(int id, TableColumn<Admin, String> name, TableColumn<Admin, String> email, TableColumn<Admin, Integer> password) {
        }

        public Admin(int id, String name, String email, String password) {
        }

        public Label getWelcomeText() {
            return welcomeText;
        }

        public void setWelcomeText(Label welcomeText) {
            this.welcomeText = welcomeText;
        }

        public int getID() {
            return ID;
        }

        public void setID(int ID) {
            this.ID = ID;
        }

        public String getName() {
            return Name;
        }

        public void setName(String name) {
            Name = name;
        }

        public String getEmail() {
            return Email;
        }

        public void setEmail(String email) {
            Email = email;
        }

        public int getPassword() {
            return Password;
        }

        public void setPassword(int password) {
            Password = password;
        }

        public Admin(Label welcomeText, int ID, String name, String email, int password) {
            this.welcomeText = welcomeText;
            this.ID = ID;
            Name = name;
            Email = email;
            Password = password;
        }
    }
