package com.example.lab3;

public class Employee {
    private int id;
    private String Name;
    private String Address;
    private int Salary;
    public Employee(int id, String Name, String Address, int Salary) {
        this.id = id;
        this.Name = Name;
        this.Address = Address;
        this.Salary = Salary;
    }
    public int getID() {
        return id;
    }
    public String getName() {
        return Name;
    }
    public String getAddress() {
        return Address;
    }
    public int getSalary() {
        return Salary;
    }
}

